﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO.Ports;

namespace SerialComm
{
    class MySerialPort
    {
        private SerialPort _serialport;
        private String _lastMessage;

        public MySerialPort()
        {            
            try
            {
                _serialport = new SerialPort("COM5")
                {
                    BaudRate = 9600,
                    Parity = Parity.None,
                    StopBits = StopBits.One,
                    DataBits = 8,
                    Handshake = Handshake.None
                };

                _serialport.DataReceived += SerialportOnDataReceived;
                _serialport.Open();
            }
            catch (Exception e)
            {
                throw new Exception("Exception: SerialPort\n" + e.Message);
            }
        }

        ~MySerialPort()
        {
        _serialport.Close();    
        }

        private void SerialportOnDataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            _lastMessage = sp.ReadExisting();              
        }

        public void SendData(String message)
        {
            try
            {
                //_serialport.Write(data, 0, data.Length);
                _serialport.Write(message);
            }
            catch (Exception e)
            {                
                throw new Exception("Exception: SerialPort\n" + e.Message);
            }
        }

        public String ReceiveData()
        {
            return _lastMessage;
        }

    }
}
