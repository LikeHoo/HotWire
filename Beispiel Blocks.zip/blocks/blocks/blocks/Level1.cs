﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace blocks
{
    class Level1
    {
        public Blocks[] myblocks = new Blocks[90];
        Texture2D blockTexture;
        public static int blocksLeft = 90;
        public int Points;
        

        public Level1(Texture2D tex)
        {
            this.blockTexture = tex;
            initBlocks();
            Points = 0;
        }

        private void initBlocks()
        {

            /*
            for (int i = 0; i < 90; i++)
            {
                if (blocksLeft == 0)
                {
                    //position = new Vector(100, 100);
                    myblocks[i] = new Rectangle(100, 100, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 79)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 80) * blockTexture.Width + (blocksLeft - 80) * 1, 100 + blockTexture.Height * 8 + 8, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 69)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 70) * blockTexture.Width + (blocksLeft - 70) * 1, 100 + blockTexture.Height * 7 + 7, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 59)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 60) * blockTexture.Width + (blocksLeft - 60) * 1, 100 + blockTexture.Height * 6 + 6, blockTexture.Width, blockTexture.Height);
                }


                else if (blocksLeft > 49)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 50) * blockTexture.Width + (blocksLeft - 50) * 1, 100 + blockTexture.Height * 5 + 5, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 39)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 40) * blockTexture.Width + (blocksLeft - 40) * 1, 100 + blockTexture.Height * 4 + 4, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 29)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 30) * blockTexture.Width + (blocksLeft - 30) * 1, 100 + blockTexture.Height * 3 + 3, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 19)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 20) * blockTexture.Width + (blocksLeft - 20) * 1, 100 + blockTexture.Height * 2 + 2, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 9)
                {
                    myblocks[i] = new Rectangle(100 + (blocksLeft - 10) * blockTexture.Width + (blocksLeft - 10) * 1, 100 + blockTexture.Height + 1, blockTexture.Width, blockTexture.Height);
                }

                else if (blocksLeft > 0)
                {
                    myblocks[i] = new Rectangle(100 + blocksLeft * blockTexture.Width + blocksLeft * 1, 100, blockTexture.Width, blockTexture.Height);
                }
            }
             */
         
            
            for (int i=0;i<90;i++)
            {
                myblocks[i] = new Blocks(blockTexture, new Rectangle(100 + (i - 10*(int)Math.Floor((double)i / 10)) * blockTexture.Width + (i - 10*(int)Math.Floor((double)i / 10)) * 1, 100 + blockTexture.Height * (int)Math.Floor((double)i / 10) + (int)Math.Floor((double)i / 10), blockTexture.Width, blockTexture.Height));
                //myblocks[i] = new Rectangle((100+ (i - (Math.Floor((double)i/10))*10) * blockTexture.Width + (i-(Math.Floor((double)i/10))*10)),100,blockTexture.Width,blockTexture.Height);
            }
             
        }
               
    }
}
