﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;



namespace blocks
{
    class Blocks
    {
        //public static int blocksLeft = 0;
        
        public Rectangle rectBlock;
        //public Vector2 position;
        public bool isAlive;

        public Blocks(Texture2D tex,Rectangle rect)
        {

            this.rectBlock = rect;
                //position = new Vector2(100 + (blocksLeft * tex.Width), 100);
                
            
            isAlive = true;
            //blocksLeft++;
        }
    }
}
