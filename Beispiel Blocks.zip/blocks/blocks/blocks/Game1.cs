using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using System.IO.Ports;

struct screen
{
    public int screenHeight;
    public int screenWidth;
}

struct ball
{
    public Vector2 position;
    public Vector2 speed;
    public int ballsLeft;
}

struct paddle
{
    public Vector2 position;
    public Vector2 speed;
}


namespace blocks
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        GraphicsDevice device;
        Texture2D backgroundTexture;
        Texture2D brettTexture;
        Texture2D ballTexture;
        Texture2D blockTexture;
        screen myscreen = new screen();
        ball myball = new ball();
        paddle mypaddle = new paddle();
        SoundEffect hitPaddle;
        SoundEffect hitBlock;
        Level1 level;
        SpriteFont font;
        SerialPort sp;
        int InComing;
        int poti;
       
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 500;
            graphics.PreferredBackBufferHeight = 500;
            graphics.IsFullScreen = false;
            IsMouseVisible = true;
            //�nderungen durchf�hren.
            graphics.ApplyChanges();
            // TODO: Add your initialization logic here
          

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            backgroundTexture = Content.Load<Texture2D>("outer-space1");
            brettTexture = Content.Load<Texture2D>("brett");
            ballTexture = Content.Load<Texture2D>("ball");
            blockTexture = Content.Load<Texture2D>("block");
            level = new Level1(blockTexture);
            device = graphics.GraphicsDevice;
            myscreen.screenHeight = 500;
            myscreen.screenWidth = 500;
            hitPaddle = Content.Load<SoundEffect>("pongblipc5");
            hitBlock = Content.Load<SoundEffect>("pongblipg5");
            font = Content.Load<SpriteFont>("myFont");
            //Ball links oben initialisiert.
            myball.speed = new Vector2(75, 150);
            myball.ballsLeft = 3;
            mypaddle.position = new Vector2(device.Viewport.Width / 2 - brettTexture.Width / 2,
                device.Viewport.Height - brettTexture.Height);
            mypaddle.speed = Vector2.Zero;
            myball.position = new Vector2(mypaddle.position.X + brettTexture.Width / 2 - ballTexture.Width / 2, mypaddle.position.Y - brettTexture.Height);
            sp = new SerialPort("COM2", 19200, Parity.None,8, StopBits.One);
            poti = 49;

            sp.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(processS12x);
            try
            {
                if (!sp.IsOpen)
                {
                    sp.Open();
                }
            }
            catch (Exception)
            {
                myball.ballsLeft = 10;
            }

            try
            {
                sp.Write(myball.ballsLeft.ToString());
            }

            catch (Exception)
            {
            }

            //sp.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler();
            //blocks
            
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();
            updateBall(gameTime);
            processKeyboard();
            checkCollision();
            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            device.Clear(Color.CornflowerBlue);
            spriteBatch.Begin();
            drawScenery();
            drawText();
            drawBlocks();
            drawBrett();
            drawBall();
            spriteBatch.End();
            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }

        private void drawScenery()
        {
            Rectangle screenRectangle = new Rectangle(0, 0,myscreen.screenWidth, myscreen.screenHeight);
            spriteBatch.Draw(backgroundTexture,screenRectangle,Color.White);
        }

        private void drawBlocks()
        {
            for (int i=0;i < Level1.blocksLeft;i++)
            {
                if (level.myblocks[i].isAlive)
                {
                    spriteBatch.Draw(blockTexture, level.myblocks[i].rectBlock, Color.Yellow);
                }
                
            }
        }

        private void drawBall()
        {
            if (myball.ballsLeft > 0)
            {
                spriteBatch.Draw(ballTexture, myball.position, Color.White);
            }
            
        }

        private void drawBrett()
        {
            spriteBatch.Draw(brettTexture, mypaddle.position, Color.White);
        }


        public void processS12x(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {

            InComing = sp.ReadByte();                  // Ein Byte aus dem Eingangspuffer lesen
            
            //Program.BeginInvoke(new EventHandler(DoUpdate));       // DoUpdate-Methode aufrufen
            //Thread.Sleep(500);
            doUpdate();                      
            sp.DiscardInBuffer();                      // Puffer leeren
            
                
        }
        private void processKeyboard()
        {
            KeyboardState keyState = Keyboard.GetState();

            if (keyState.IsKeyDown(Keys.Space))
            {
                myball.position.X = mypaddle.position.X + brettTexture.Width / 2 - ballTexture.Width / 2;
                myball.position.Y = mypaddle.position.Y - brettTexture.Height;
            }

            if (keyState.IsKeyDown(Keys.Right) && mypaddle.position.X+1+brettTexture.Width < myscreen.screenWidth)
            {
                mypaddle.position.X += 5;
            }

            else if (keyState.IsKeyDown(Keys.Left) && mypaddle.position.X -1 > 0)
            {
                mypaddle.position.X -= 5;
            }

            else if (keyState.IsKeyDown(Keys.Z))
            {
                for (int i = 0; i < Level1.blocksLeft; i++)
                {
                    level.myblocks[i].isAlive = false;
                }

                Level1.blocksLeft = 0;
            }

            if (keyState.IsKeyDown(Keys.R))
            {
                for (int i=0;i<90;i++)
                {
                    level.myblocks[i].isAlive = true;
                }
                myball.ballsLeft = 3;
                level.Points = 0;

                try
                {
                    if (myball.ballsLeft >= 0 && myball.ballsLeft < 4)
                    {
                        sp.Write(myball.ballsLeft.ToString());
                    }
                }
                catch (Exception)
                {
                }
            }

          
        }

        private void updateBall(GameTime gameTime)
        {
            if (myball.ballsLeft > 0)
            {

                myball.position += myball.speed * (float)gameTime.ElapsedGameTime.TotalSeconds;

                int maxX = device.Viewport.Width - ballTexture.Width;
                int maxY = device.Viewport.Height - ballTexture.Height;

                //check for bounce
                if (myball.position.X > maxX || myball.position.X < 0)
                {
                    myball.speed.X *= -1;
                }

                if (myball.position.Y < 0)
                {
                    myball.speed.Y *= -1;
                }

                else if (myball.position.Y > maxY)
                {
                    myball.ballsLeft--;
                    try
                    {
                        if (myball.ballsLeft >= 0 && myball.ballsLeft < 4)
                        {
                            sp.Write(myball.ballsLeft.ToString());
                        }
                    }
                    catch (Exception)
                    {
                    }
                    myball.position.X = mypaddle.position.X + brettTexture.Width / 2 - ballTexture.Width / 2;
                    myball.position.Y = mypaddle.position.Y - brettTexture.Height;
                    myball.speed.Y = 150;
                    myball.speed.X = 75;
                }
            }

        }

        public void checkCollision()
        {
            Rectangle ballRect = new Rectangle((int)myball.position.X, (int)myball.position.Y,
                ballTexture.Width, ballTexture.Height);
            Rectangle paddleRect = new Rectangle((int)mypaddle.position.X, (int)mypaddle.position.Y,
                brettTexture.Width, brettTexture.Height);

            for (int i=0;i<Level1.blocksLeft;i++)
            {
                if (ballRect.Intersects(level.myblocks[i].rectBlock) && level.myblocks[i].isAlive)
                {
                    hitBlock.Play();
                    level.Points += 1;
                    level.myblocks[i].isAlive = false;
                    myball.speed.Y *= -1;
                    i = Level1.blocksLeft;
                }
            }


            if (ballRect.Intersects(paddleRect) && myball.speed.Y > 0)
            {
                hitPaddle.Play();
                KeyboardState keyState = Keyboard.GetState();

                if (keyState.IsKeyDown(Keys.Right) && myball.speed.X > 0)
                {
                    myball.speed.X += 50;
                    myball.speed.Y += 20;
                }

                else if (keyState.IsKeyDown(Keys.Right) && myball.speed.X < 0)
                {
                    myball.speed.X += 50;
                    myball.speed.Y -= 20;
                }

                if (keyState.IsKeyDown(Keys.Left) && myball.speed.X > 0)
                {
                    myball.speed.X -= 50;
                    myball.speed.Y -= 20;
                }

                else if (keyState.IsKeyDown(Keys.Left) && myball.speed.X < 0)
                {
                    myball.speed.X -= 50;
                    myball.speed.Y += 20;
                        
                }
                
                myball.speed.Y += 5;
                myball.speed.Y *= -1;
            }
        }

        private void drawText()
        {
            spriteBatch.DrawString(font, "Balls:" + myball.ballsLeft, new Vector2(10, 10), Color.White);
            spriteBatch.DrawString(font, "Points:" + level.Points, new Vector2(410, 10), Color.White);
        }

        private void doUpdate()
        {
             if (InComing == 49 && mypaddle.position.X + 1 + brettTexture.Width < myscreen.screenWidth)
            {
                mypaddle.position.X += 10;
            }

            else if (InComing == 50 && mypaddle.position.X - 1 > 0)
            {
                mypaddle.position.X -= 10;
            }

            else if (poti != InComing)
            {

                myball.speed.Y += (InComing - poti);
                poti = InComing;
            }
        }
    }
}
